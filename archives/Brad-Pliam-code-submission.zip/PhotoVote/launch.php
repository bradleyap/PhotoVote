<?php

$servername = "unitraverse.com";
$dbuser = "turkeytrot";
$dbpwd = "f36Vrt9B#!";
$dbname = "web_demo_store";

$msg = $_POST['msg'];
list($xtnKey,$guid,$user,$pwd) = explode(':',$msg,4);

$rspnStr = '{"xtn_key":"' . $xtnKey . '","response_json":"';

$conn = new mysqli($servername,$dbuser,$dbpwd,$dbname);
if ($conn->connect_error) {
    $conn = new mysqli($servername,$user,$pwd,$dbname);
    if ($conn->connect_error) {
        echo $rspnStr . 'login_failed"}';
        die("select query failed: " . mysqli_connect_error() . "\"}");
    }
}

$query = "SELECT * FROM `photo_vote_user` WHERE `username` = \"" . $user . "\" && `pswd` = \"" . $pwd . "\"";

$rslt =  $conn->query($query);
if ($rslt === FALSE){
    printf("Error: %s; ", $conn->error);
    $conn->close();
    echo $rspnStr . 'login_failed"}';
    die("mysqli SELECT of account on user failed;\"}");
}

if($rslt->num_rows == 0){
    echo $rspnStr . 'login_failed with pswd: ' . $pwd . '"}';
    exit(0);
}

if (empty($rslt)){
    printf("Error: %s; ", $conn->error);
    echo $rspnStr . 'login_failed with user: ' . $user;
    $conn->close();
    die("mysqli select on 'username' " . $user . "' failed;\"}");
}

$tuple = mysqli_fetch_array($rslt, MYSQLI_ASSOC); 
if($tuple === False){
    printf("Error: %s; ", $conn->error);
    $conn->close();
    die("Error: getting array info from tuples\"}");
}

$userId = $tuple['id'];

$date_time = date("Y-m-d H:i:s");       
$stmt = "INSERT INTO `session_info`(`user_id`,`session_guid`,`start_time`) VALUES ('" . $userId . "','" . $guid . "','" . $date_time . "')";
if($conn->query($stmt) == False){
    echo $rspnStr . 'login_failed"}';
    printf("Error: %s; ", $conn->error);
    $conn->close();
    echo "\"}";
    exit(1);
}
else{
    echo $rspnStr . 'login_succeeded"}';
}

$conn->close();


