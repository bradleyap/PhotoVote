
<?php

/* Save and access photoVote tournament records */

function getUserIdFromUsername($conn,$username,$rspnString){
    $query = 'SELECT `id` FROM `photo_vote_user` WHERE `username` = "' . $username . '"';
    
    $rslt =  $conn->query($query);
    if ($rslt === FALSE){
        printf("Error: %s; ", $conn->error);
        $conn->close();
        echo $rspnString . 'status_update_failed"}';
        die("mysqli SELECT of 'id' on 'username' failed;\"}");
    }
    if($rslt->num_rows != 1){
        echo $rspnString . 'status_update_failed with user: ' . $username . '"}';
        exit(0);
    }
    
    $tuple = mysqli_fetch_array($rslt, MYSQLI_ASSOC); 
    if($tuple === False){
        printf("Error: %s; ", $conn->error);
        $conn->close();
        die("Error: getting array info from tuples\"}");
    }

    return $tuple['id'];
}

$servername = "unitraverse.com";
$dbuser = "turkeytrot";
$dbpwd = "f36Vrt9B#!";
$dbname = "web_demo_store";
$verb = 'GET';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $msg = $_POST['msg'];
    list($xtnKey,$guid,$user,$pwd,$data) = explode(':',$msg,5);
    $verb = 'POST';
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $msg = $_GET['msg'];
    list($xtnKey,$guid,$user,$pwd) = explode(':',$msg,4);
}

if(strlen($msg) < 1){
    echo '{"response_json":"stats_update_failed","error":"bad \'msg\' variable"}';
    exit(0);
}

$rspnStr = '{"xtn_key":"' . $xtnKey . '","response_json":"';

$conn = new mysqli($servername,$dbuser,$dbpwd,$dbname);
if ($conn->connect_error) {
    $conn = new mysqli($servername,$user,$pwd,$dbname);
    if($conn->connect_error) {
        $conn->close();
        echo $rspnStr . 'stats_backend_failed","error_msg":"select query failed ' . mysqli_connect_error() . '"}';
        exit(0);
    }
}

if($verb === 'GET'){
    $query = "SELECT username, end_time, photo_url_data, winner_sequence, winner_cd FROM tournament INNER JOIN photo_vote_user ON user_id = photo_vote_user.id";

    $rslt =  $conn->query($query);
    if ($rslt === FALSE){
        $conn->close();
        echo $rspnStr . 'stats_backend_inner_join_failed","error_msg":"';
        printf("Error: %s; ", $conn->error);
        echo '"}';
        exit(0);
    }

    $tuple = NULL;
    $rowArr = [];
    do{        
        $tuple = mysqli_fetch_array($rslt, MYSQLI_ASSOC); 
        if($tuple === False){
            printf("Error: %s; ", $conn->error);
            $conn->close();
            die("Error: getting array info from tuples\"}");
        }
        if($tuple){
            array_push($rowArr,$tuple);
        }
    } while($tuple);
    
    echo '{"xtn_key":"' . $xtnKey . '","response_json":"fetch_succeeded","history_data":' . json_encode($rowArr) . '}';
}
else{
    list($contenders,$choices,$winner) = explode('|',$data,3);

    $user_id = getUserIdFromUsername($conn,$user,$rspnStr);
    
    $stmt = "INSERT INTO `tournament`(`photo_url_data`,`user_id`,`winner_cd`,`winner_sequence`) VALUES ('" . $contenders . "','" . $user_id . "','" . $winner . "','" . $choices . "')";
    
    if($conn->query($stmt) == False){
        echo $rspnStr . 'stats_update_failed"}';
        printf("Error: %s; ", $conn->error);
        $conn->close();
        echo "\"}";
        exit(0);
    }
    else{
        echo $rspnStr . 'stats_update_succeeded"}';
    }
}


?>