<?php

$servername = "unitraverse.com";
$dbuser = "turkeytrot";
$dbpwd = "f36Vrt9B#!";
$dbname = "web_demo_store";

$msg = $_POST['msg'];
list($xtnKey,$guid,$user,$pwd) = explode(':',$msg,4);

$rspnStr = '{"xtn_key":"' . $xtnKey . '","response_json":"';

$conn = new mysqli($servername,$dbuser,$dbpwd,$dbname);
if ($conn->connect_error) {
    $conn = new mysqli($servername,$user,$pwd,$dbname);
    if($conn->connect_error) {
        echo $rspnStr . 'registration_failed"}';
        die("select query failed: " . mysqli_connect_error() . "\"}");
    }
}

$query = "SELECT * FROM `photo_vote_user` WHERE `username` = \"" . $user . "\"";

$rslt =  $conn->query($query);
if ($rslt === FALSE){
    printf("Error: %s; ", $conn->error);
    $conn->close();
    echo $rspnStr . 'registration_failed"}';
    die("mysqli SELECT of account on user failed;\"}");
}
if($rslt->num_rows > 0){
    echo $rspnStr . 'registration_failed with user: ' . $user . '"}';
    exit(0);
}

#$date_time = date("Y-m-d H:i:s");       
$stmt = "INSERT INTO `photo_vote_user`(`username`,`pswd`) VALUES ('" . $user . "','" . $pwd . "')";

if($conn->query($stmt) == False){
    echo $rspnStr . 'registration_failed"}';
    printf("Error: %s; ", $conn->error);
    $conn->close();
    echo "\"}";
    exit(1);
}
else{
    echo $rspnStr . 'registration_succeeded"}';
}

$conn->close();




