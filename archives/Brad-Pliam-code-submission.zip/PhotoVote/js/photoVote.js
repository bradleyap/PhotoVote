//photoVote.js

/*
  Web application - tournament platform for mutiple users to vote on dynamically loaded photos, view tournament history
*/

var gScreen = {blur_element:null,login_element:null}; 
var gDOM_elements = {};
var gUsername = '';
var gPassword = '';
var gTournament = null;


////////////  App initialization  ////////////////////////

function initializeApp(){
    var elmt = gDOM_elements.blur_panel = document.createElement('div');
    elmt.setAttribute('id','blur-panel');
    elmt.setAttribute('display','none');
    document.body.appendChild(elmt);

    elmt = gDOM_elements.login_pane = document.createElement('div');
    elmt.setAttribute('style','display:none');
    elmt.setAttribute('id','login_pane');
    elmt.innerHTML = 'username: <input id="userEdit" type="edit"></input><p/>password: <input id="userPswd" type="edit"></input><p/><div id="sign-in-status"></div><p/><input type="button" onclick="doLogin()" value="login"></input><input type="button" value="register" onclick="doRegister()"></input>';
    document.body.appendChild(elmt);
    
    //for developers to skip login...
    var searchStr = window.location.href;
    var userStr = "";
    var pwdStr = "";
    var qindex = searchStr.indexOf('?');
    if(qindex > -1){
        searchStr = searchStr.substring(qindex + 1);
        var arr = searchStr.split("&");
        for(var i=0; i<arr.length; i++){
            if(arr[i].indexOf("user=") == 0){
                userStr = arr[i].substring(5);
            }
            if(arr[i].indexOf("pwd=") == 0){
                pwdStr = arr[i].substring(4);
            }
        }
    }
    if(pwdStr === "" || userStr === ""){ //do login
        showPopup('login_pane');
    }
    else{ //skip login
        hidePopup('login_pane');
        gUsername = userStr;
        gPassword = pwdStr;
        onLaunch();
    }
}

////////////  Login and Registration  ////////////////////////

function doLogin(){
    gUsername = document.getElementById('userEdit').value;
    gPassword = document.getElementById('userPswd').value;
    var guid = Math.random();
    makeHttpRequest('POST','launch.php','pseudokey123:' + guid + ':' + gUsername + ':' + gPassword,[],[],'','');
}

function doRegister(){
    gUsername = document.getElementById('userEdit').value;
    gPassword = document.getElementById('userPswd').value;
    makeHttpRequest('POST','register.php','pseudokey123:pseudoGUID:' + gUsername + ':' + gPassword,[],[],'','');
}

function onUserRegistered(){
    displaySignInStatus("Registration successful!");
}

function onLaunch(){
    //hide login pane
    hidePopup('login_pane');
    
    //add main menu
    var elmt = gDOM_elements.main_menu = document.createElement('div');
    elmt.innerHTML = '<div id="std-menu"><div id="log_out_btn">log out</div><div id="start_tournament_btn">start a tournament</div><div id="history_btn">view history</div></div>';
    document.body.appendChild(elmt);
    
    elmt = document.getElementById('start_tournament_btn');
    elmt.addEventListener('click',getTournamentInfo);
    elmt = document.getElementById('log_out_btn');
    elmt.addEventListener('click',function(){window.location.href="index.html";});
    elmt = document.getElementById('history_btn');
    elmt.addEventListener('click',viewTournamentHistory);

    //add status pane for error messages
    elmt = gDOM_elements.main_menu = document.createElement('div');
    elmt.setAttribute('id','status-pane');
    document.body.appendChild(elmt);
    
    //add content pane
    elmt = gDOM_elements.content = document.createElement('div');
    elmt.setAttribute('id','content-pane');
    document.body.appendChild(elmt);
    
    sizeAndPositionContentPane();
    
}

function displaySignInStatus(str){
    document.getElementById('sign-in-status').innerText = str;
}

////////////  Ajax requests  ////////////////////////

var waitingQueue = [];
var suspendPacketSzLimit = false;

function makeHttpRequest(httpVerb,fileStr,msg,paramLst,hdrLst,usr,pwd){
    var xmlhttp;    
    if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }
    else {// code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange=function(){
        if (xmlhttp.readyState==4 && xmlhttp.status==200){
            handleHttpResponse(xmlhttp);
        }
    }
    var paramStr = "";
    var plSep = ""; //plSep - parameter list separator
    var portSep = ":";
    var querySep = "?";
    var pathStr = "";
    var pathSep = '/';
    var pathArr = window.location.pathname.split(pathSep);
    for(var i=0; i<pathArr.length - 1; i++){
        if(pathArr[i] === '')continue;
        pathStr += '/' + pathArr[i];
    }
    if(pathStr === '/'){
        pathSep = ''; 
    }
    pathStr += '/' + fileStr;
    if(window.location.port === "")portSep = "";
    var urlString = "http://" + window.location.hostname + portSep + window.location.port + "/" + pathStr;
    var sendMsg = "";
    if(msg !== ""){
        msg = "msg=" + msg;
    }
    if(paramLst.length > 0){
        for(var i=0; i<paramLst.length; i++){
            paramStr += plSep + paramLst[i];
            plSep = "&"; 
        }
    }
    if(httpVerb === "GET"){
        if(msg !== ""){
            paramStr += plSep + msg;
        }
    }
    else{
        sendMsg = msg;
    }
    urlString += querySep + paramStr;
    xmlhttp.open(httpVerb,urlString,true,usr,pwd); 
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlhttp.send(sendMsg);
}

function handleHttpResponse(httpResponse){
    var rsLen = httpResponse.responseText.length;
    if(rsLen < 500000 || suspendPacketSzLimit){
        if(rsLen >= 500000)suspendPacketSzLimit = false;
        if(httpResponse.responseText.indexOf('xtn_key') > -1){
            //safeParseJSON will catch errors and report
            var jsonOb = safeParseJSON(httpResponse.responseText);
            if(jsonOb == null){
                return;
            }
            var ostr = jsonOb.response_json;
            if(ostr === 'registration_succeeded'){
                onUserRegistered();
            }
            if(ostr.indexOf('registration_failed') > -1){
                displaySignInStatus(ostr);
            }
            if(ostr === 'login_succeeded'){
                onLaunch();
            }
            if(ostr.indexOf('login_failed') > -1){
                displaySignInStatus(ostr);
            }
            if(ostr === 'fetch_succeeded'){
                displayTournamentHistory(jsonOb.history_data);
            }
            if(ostr.indexOf('stats_backend_failed') > -1){
                var msg = "There was a problem fetching tournament results. "
                if(typeof jsonOb.error_msg !== 'undefined'){
                    msg += "Details: " + jsonOb.error_msg;
                }
                displayErrorMessage(msg);
            }
            if(ostr === 'api_accessor_failed'){
                var msg = '"There was a problem accessing the photo-voting API: https://photo-voting.hiring.ipums.org/images/"'; 
                if(typeof jsonOb.error_msg !== 'undefined'){
                    msg += "Details: " + jsonOb.error_msg;
                }
                displayErrorMessage(msg);
            }
        }
        else{ //API call not inserting extension key
            //safeParseJSON will catch errors and report
            var jsonOb = safeParseJSON(httpResponse.responseText);
            if(jsonOb.status.toUpperCase() === "OK"){
                startTournament(jsonOb.data);
            }
        }
    }
}

function safeParseJSON(jsonString){
    var jsonOb = null;
    try {
        jsonOb = JSON.parse(jsonString);
    }
    catch(err) {
        var msg = "JSON.parse "
        displayErrorMessage("JSON.parse() found invalid JSON string. Details: " + err.message);
    }
    return jsonOb;
}



////////////  Tournament setup and operations ////////////////////////

function getTournamentInfo(){
    makeHttpRequest('GET','accessAPI.php','pseudokey123:pseudoGUID:pseuedoUser:pseudoPwd',[],[],'','');
}

function startTournament(data){
    gTournament = new Tournament(data);
    console.log(data);
    gTournament.start();    
}

function updateTournamentHistory(contenders,choices,winner){
    var dataStr = contenders + '|' + choices + '|' + winner; 
    makeHttpRequest('POST','stats.php','pseudokey123:pseudoGUID:' + gUsername + ':pseudoPwd:' + dataStr,[],[],'','');
    console.log(dataStr);
}

function viewTournamentHistory(){
    makeHttpRequest('GET','stats.php','pseudokey123:pseudoGUID:pseuedoUser:pseudoPwd',[],[],'','');
}

function displayTournamentHistory(data){
    var elmt = gDOM_elements.content;
    var html = '<div class="content-hdr">Tournament History</div><table id="history-table"><tr><th>Tournament <br/>Judge</th><th>Winning <br/>Photo</th></tr>';
    for(var i=0; i<data.length; i++){
        html += '<tr><td class="cell-data-odd">' + data[i].username  + '</td><td class="cell-data-even"><img src="' + convertWinnerCodeToUrl(data[i].winner_cd) + '"/></td></tr>';
    }
    html += '</table><div class="clearfix"></div>';
    elmt.innerHTML = html;

    /*
    images are not yet loaded when this code executes... we need to wait a bit and then calculate and extend the content background to accommodate the area. Adding a div implementing the 'clearfix' css workaround hasn't worked, probably because of absolute positioning of the history table
    */
    var tblElmt = document.getElementById('history-table');

    var origTop = tblElmt.getBoundingClientRect().top; //valid when no images are loaded into the header that increase the size after they're loaded 
    
    var pollingProc = setInterval(function(){
        extendContentPaneHeight(tblElmt,origTop);
        clearInterval(pollingProc);
    },2500);
}

function convertWinnerCodeToUrl(cd){
    return 'https://photo-voting.hiring.ipums.org/images/' + cd + '.jpg';
}

class Tournament{
    constructor(data){
        this.choiceSequence = [];
        this.urls = data;
        this.workingUrls = this.urls.slice();
        this.currentRound = new Round(data,1,this);
    }
    start(){
        this.currentRound.start();                
        //for develpers:
        //this.workingUrls = ["https://photo-voting.hiring.ipums.org/images/121.jpg"];
        //this.declareWinner();
    }
    continueTournament(choices){
        this.choiceSequence = this.choiceSequence.concat(choices);
        this.removeLosers(choices);
        if(this.workingUrls.length == 1){
            this.declareWinner();
            this.reportWinner();
            return;
        }
        var num = this.currentRound.number + 1;
        this.currentRound = new Round(this.workingUrls,num,this);
        this.currentRound.start();
    }
    getCurrentRound(){
        return this.currentRound;
    }
    removeLosers(choices){
        var cpy = [];
        var pos = 0;
        for(var i=0; i<this.workingUrls.length; i += 2){
            if(choices[pos] === 'a'){
                cpy.push(this.workingUrls[i]);
            }
            else{
                cpy.push(this.workingUrls[i + 1]);
            }
            pos++;
        }
        this.workingUrls = cpy;
    }
    declareWinner(){
        var elmt = gDOM_elements.content;
        elmt.innerHTML = '<div class="content-hdr">Tournament Result</div><div class="picture-frm"><img src="' + this.workingUrls[0] + '"/><div id="a-box" class="choice-box"  style="background-image: url(\'images/gold-ribbon.png\'); background-repeat: no-repeat"></div><div style="font-size: 34px; color: #e5b200; padding: 15px;">We have a Winner!</div>';
    }
    reportWinner(){
        var contenderList = [];
        var num = -1;
        for(var i=0; i<this.urls.length; i++){
            contenderList.push(this.extractImageNumber(this.urls[i]));
        }
        updateTournamentHistory(contenderList.join(','),this.choiceSequence,this.extractImageNumber(this.workingUrls[0]));
    }
    extractImageNumber(url){
        var arr = url.split('/');
        arr = arr[arr.length - 1].split('.');
        return arr[0];
    }
}

class Round{
    constructor(data,number,tournament){
        this.number = number;
        this.lastIdx = 1;
        this.urls = data;
        this.tournament = tournament;
        this.match = new Match(this);
        this.selectionSequence = [];
    }
    start(){
        this.match.commenceVote(this.urls[0],this.urls[1]);
    }
    continueRound(choice){
        this.selectionSequence.push(choice);
        this.lastIdx += 2;
        if(this.lastIdx > this.urls.length - 1){
            this.tournament.continueTournament(this.selectionSequence);
        }
        else{
            this.match.commenceVote(this.urls[this.lastIdx - 1],this.urls[this.lastIdx]);
        }
    }
    getCurrentMatch(){
        return this.match;
    }
}

class Match{
    constructor(round){
        this.choice = '';
        this.round = round;
    }
    commenceVote(a,b){
        this.choice = '';
        var elmt = gDOM_elements.content;
        elmt.innerHTML = '<div class="content-hdr">Round ' + this.round.number + '</div><div class="picture-frm"><img src="' + a + '"/><div id="a-box" class="choice-box"></div></div><div class="picture-frm"><img src="' + b + '"/><div id="b-box" class="choice-box"></div></div><div id="next-btn">Next</div>';
        elmt = document.getElementById('a-box');
        elmt.addEventListener('click',this.chooseA);
        elmt = document.getElementById('b-box');
        elmt.addEventListener('click',this.chooseB);
        elmt = document.getElementById('next-btn');
        elmt.addEventListener('click',this.processVote);
    }
    processVote(){
        var cm = gTournament.getCurrentRound().getCurrentMatch();
        if(cm.choice === ''){
            alert('Please make a choice before moving to the next pair.');
            return;
        }
        cm.round.continueRound(cm.choice);
    }
    chooseA(){
        var cm = gTournament.getCurrentRound().getCurrentMatch();
        cm.select(false);
        cm.choice = 'a'; 
        cm.select(true);
    }
    chooseB(){
        var cm = gTournament.getCurrentRound().getCurrentMatch();
        cm.select(false);
        cm.choice = 'b'; 
        cm.select(true);
    }
    select(sel){
        if(this.choice === '')return;
        var elmt = document.getElementById(this.choice + '-box');
        if(sel){
            elmt.style.backgroundImage = 'url(images/checked-box.png)';
        }
        else{
            elmt.style.backgroundImage = 'url(images/blank-box.png)';
        }
    }
}



////////////  GUI support ////////////////////////

function setCssProperties(element,pMap){
    var keys = Object.keys(pMap);
    var style = '';
    var sep = '';
    for(var i=0; i<keys.length; i++){
        style += sep + '"' + [keys[i]] + '":"' + pMap[keys[i]] + '"'; 
        sep = ',';
    }
    element.setAttribute('style',style);
}

function showPopup(paneId){
    if(gDOM_elements[paneId] === 'undefined'){
        console.log('Invalid pane id passed into showPopup method. ')
        return;
    }
    gDOM_elements.blur_panel.style.display = 'block';
    gDOM_elements[paneId].style.display = 'block';
}

function hidePopup(paneId){
    if(gDOM_elements[paneId] === 'undefined'){
        console.log('Invalid pane id passed into hidePopup method. ')
        return;
    }
    gDOM_elements.blur_panel.style.display = 'none';
    gDOM_elements[paneId].style.display = 'none';
}

function sizeAndPositionContentPane(){
    var cpElmt = gDOM_elements.content;
    //var mBox = gDOM_elements.main_menu.getBoundingClientRect();
    var mBox = document.getElementById('std-menu').getBoundingClientRect();
    var cpTop = 0;
    var cpLeft = mBox.right + 15; //15 pixel gutter typ.
    var cpWidth = window.innerWidth - (mBox.width + 15);
    var cpHeight = window.innerHeight;
    if(window.innerWidth < window.innerHeight){
        cpTop = mBox.bottom + 15;
        cpLeft = 0;
        cpWidth = window.innerWidth;
        cpHeight = window.innerHeight - (mBox.height + 15);
    }
    cpElmt.style.left = cpLeft + 'px';
    cpElmt.style.top = cpTop + 'px';
    cpElmt.style.width = cpWidth + 'px';
    cpElmt.style.height = cpWidth + 'px';
}

function extendContentPaneHeight(lowerElement,originalTopPxls){
    var cpElmt = gDOM_elements.content;
    var box = lowerElement.getBoundingClientRect();
    if(((box.bottom - box.top) + originalTopPxls) > window.innerHeight){
        cpElmt.style.height = ((box.bottom - box.top) + originalTopPxls) + 'px';
    }
}



////////////  Error reporting  ////////////////////////

function displayErrorMessage(msg){
    var statusElmt = document.getElementById('status-pane');
    statusElmt.innerHTML = 'ERROR MESSAGE: ' + msg;
    statusElmt.style.display = 'block';
}

